import AdminOrdersView from "@/components/admin-view/orders";

function AdminOrders() {
  return (
    <div>
      <AdminOrdersView />
    </div>
  );
}

export default AdminOrders;
